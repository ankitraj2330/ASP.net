﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace test.Models
{
    public class Govcapuser
    {   [Key]
        public int UserId { get; set; }
        public int CompanyId { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        [Required]
        public String LastName { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        [Required]
        public String FirstName { get; set; }
        public String Address { get; set; }
        public int Phone { get; set; }
        [Required]
        public int Email { get; set; }
        [Required]
        public String Password { get; set; }
        public Boolean IsAdmin { get; set; }
        public int Gender { get; set; }
        public int Race { get; set; }
        public int CompanyLength { get; set; }
        public int RoleLength { get; set; }
        public int InsertedOn { get; set; }
        public int InsertedBy { get; set; }
        public int UpdatedOn { get; set; }
        public int UpdatedBy { get; set; }
        public int DeletedOn { get; set; }
        public int DeletedBy { get; set; }
    }
}

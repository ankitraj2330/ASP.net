﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCS.Models
{
    public class OutcomeCompanyViewModel
    {
        public Company company { get; set; }
        public Outcome outcome { get; set; }
    }
}
